export class MoodleRes {
  error: boolean | string;
  data?: any[];
  errorcode?: string;
  debuginfo?: string;
  reproductionlink?: string;
  stacktrace?: string;
}
