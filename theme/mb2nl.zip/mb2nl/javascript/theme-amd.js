require(["theme_boost/loader"]),require(["theme_boost/tooltip"],function(){$('[data-toggle="tooltip"]').tooltip()});
