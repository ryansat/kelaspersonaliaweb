# Firebase Performance Monitoring for Web Codelab - Start code

This folder contains the starting code for the [Firebase Performance Monitoring
for Web Codelab](https://codelabs.developers.google.com/codelabs/firebase-perf-mon-web/).

If you'd like to jump directly to the end and see the finished code head to the [performance-monitoring](../performance-monitoring) directory.
