---
name: Codelab issue
about: Report an error in a codelab that uses friendlychat-web
title: ''
labels: codelab
assignees: ''

---

### [REQUIRED] Codelab info

<!-- Which codelab are you following? To make sure we can help, include a link to the codelab and specific information about what step needs improvement  -->

### [REQUIRED] Project setup

<!-- let us know which directory of friendlychat-web you're using, as well as any other relevant details -->

### [REQUIRED] Describe the problem

<!-- Is it a grammatical error, incorrect code snippet, or are you running into an unknown bug? --> 

### [Optional] Suggested fix
